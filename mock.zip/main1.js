const canvas = document.querySelector(`canvas`);
const gl = canvas.getContext(`webgl2`);

gl.enable(gl.DEPTH_TEST);
gl.depthFunc(gl.LEQUAL);

gl.clearColor(0.2,0.2,0.2,1);
gl.clear(gl.COLOR_BUFFER_BIT);

const vSrc = 
`#version 300 es
in vec3 v_pos;
in vec3 v_col;
out vec3 f_col;

uniform mat4 mRot;
uniform mat4 mShift;
uniform mat4 mPersp;
uniform mat4 mCam;

void main() {
    gl_Position = mPersp * mCam * mShift * mRot * vec4(v_pos, 1);
    gl_PointSize = 40.0;
    f_col = v_col;
}
`;

const fSrc = 
`#version 300 es
precision mediump float;

in vec3 f_col;
out vec4 outColor;

void main() {
    outColor = vec4(f_col, 1);
}
`;

const vShader = gl.createShader(gl.VERTEX_SHADER);
const fShader = gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(vShader, vSrc);
gl.shaderSource(fShader, fSrc);
gl.compileShader(vShader);
gl.compileShader(fShader);

const program = gl.createProgram();
gl.attachShader(program, vShader);
gl.attachShader(program, fShader);
gl.linkProgram(program);
gl.useProgram(program);

const buf = gl.createBuffer();
const radius = 0.3;
const front = [radius, radius, radius];
const back = [-radius, -radius, -radius];
const vert = [];

function pushSquare(arr, c, dc1, dc2, colour){
    arr.push(
        c[0],c[1],c[2],                         colour[0],colour[1],colour[2],
        c[0]+dc1[0],c[1]+dc1[1],c[2]+dc1[2],    colour[0],colour[1],colour[2],
        c[0]+dc2[0],c[1]+dc2[1],c[2]+dc2[2],    colour[0],colour[1],colour[2],
    
        c[0]+dc1[0],c[1]+dc1[1],c[2]+dc1[2],    colour[0],colour[1],colour[2],
        c[0]+dc2[0],c[1]+dc2[1],c[2]+dc2[2],    colour[0],colour[1],colour[2],
        c[0]+dc1[0]+dc2[0],c[1]+dc1[1]+dc2[1],c[2]+dc1[2]+dc2[2],    colour[0],colour[1],colour[2]
    )
}
//pushSquare(vert,[-0.5,-0.5,0],[0.5,0.7,0],[1,0.1,0],[1,1,1]);

const jump = 2*radius;

pushSquare(vert, front, [-jump,0,0], [0,-jump,0], [0.7,0.7,1]);
pushSquare(vert, front, [0,-jump,0], [0,0,-jump], [0.7,1,0.7]);
pushSquare(vert, front, [0,0,-jump], [-jump,0,0], [1,0.7,0.7]);

pushSquare(vert, back, [jump,0,0], [0,jump,0], [0.3,0.3,1]);
pushSquare(vert, back, [0,jump,0], [0,0,jump], [0.3,1,0.3]);
pushSquare(vert, back, [0,0,jump], [jump,0,0], [1,0.3,0.3]);

gl.bindBuffer(gl.ARRAY_BUFFER, buf);
gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vert), gl.STATIC_DRAW);

const posLoc = gl.getAttribLocation(program, `v_pos`);
const colLoc = gl.getAttribLocation(program, `v_col`);

const rotLoc = gl.getUniformLocation(program, `mRot`);
const shiftLoc = gl.getUniformLocation(program, `mShift`);
const perspLoc = gl.getUniformLocation(program, `mPersp`);
const camLoc = gl.getUniformLocation(program, `mCam`);

const r = [0,0,0];
const inc = Math.PI / 90;
const a = [0,0,0];

function btnA() {
    if (a[0] == 0) {
        a[0] = inc;
    }
    else {
        a[0] = 0;
    }
}

function btnB() {
    if (a[1] == 0) {
        a[1] = inc;
    }
    else {
        a[1] = 0;
    }
}

function btnC() {
    if (a[2] == 0) {
        a[2] = inc;
    }
    else {
        a[2] = 0;
    }
}

const sh = [0,0,-1.7];
const ish = 0.05;

function btnD() {
 sh[0] += ish;
}

function btnE() {
 sh[0] -= ish;
}


function btnF() {
 sh[1] += ish;
}

function btnG() {
 sh[1] -= ish;
}


function btnH() {
 sh[2] += ish;
}

function btnI() {
 sh[2] -= ish;
}

const cs = [0,0,0];

function btnJ() {
 cs[0] += ish;
}

function btnK() {
 cs[0] -= ish;
}


function btnL() {
 cs[1] += ish;
}

function btnM() {
 cs[1] -= ish;
}


function btnN() {
 cs[2] += ish;
}

function btnO() {
 cs[2] -= ish;
}

function activateBuffer(buffer) {
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.enableVertexAttribArray(posLoc);
    gl.enableVertexAttribArray(colLoc);
    gl.vertexAttribPointer(posLoc, 3, gl.FLOAT, false, 4*6, 0);
    gl.vertexAttribPointer(colLoc, 3, gl.FLOAT, false, 4*6, 4*3);
}

function makeRotMatrix(a,b,c) {
    const m = [];
    const cos = [Math.cos(-a),Math.cos(-b), Math.cos(c)];
    const sin = [Math.sin(-a),Math.sin(-b), Math.sin(c)];

    m.push(cos[1]*cos[2]);
    m.push(cos[1]*sin[2]);
    m.push(-sin[1]);
    m.push(0);
    
    m.push(sin[0]*sin[1]*cos[2]-cos[0]*sin[2]);
    m.push(sin[0]*sin[1]*sin[2]+cos[0]*cos[2]);
    m.push(sin[0]*cos[1]);
    m.push(0);
    
    m.push(cos[0]*sin[1]*cos[2]+sin[0]*sin[2]);
    m.push(cos[0]*sin[1]*sin[2]-sin[0]*cos[2]);
    m.push(cos[0]*cos[1]);
    m.push(0);
    
    m.push(0);
    m.push(0);
    m.push(0);
    m.push(1);

    return m;
}

function m4() {
 const m = [];
 for (let i = 0; i < 16; i++){
  m.push(0);
 }
 
 m[0] = 1;
 m[5] = 1;
 m[10] = 1;
 m[15] = 1;
 
 return m;
}

function makeShiftMatrix(a,b,c) {
 const m = m4();
 m[12] = a;
 m[13] = b;
 m[14] = c;
 return m;
}

function makePerspMatrix(n,f,r,t) {
 const m = m4();
 m[0] = n / r;
 m[5] = n / t;
 m[10] = (f+n) / (n-f);
 m[11] = -1;
 m[14] = (2*f*n) / (n-f);
 m[15] = 0;
 return m;
}

function makeFOVMatrix(n,f,fovy,aspect) {
 const tangent = Math.tan(fovy/2 * (Math.PI / 180));
 const t = n * tangent;
 const r = t * aspect;
 return makePerspMatrix(n,f,r,t);
}

function setUniforms(r,s,p,c) {
 gl.uniformMatrix4fv(rotLoc, false, new Float32Array(r));
 gl.uniformMatrix4fv(shiftLoc, false, new Float32Array(s));
 gl.uniformMatrix4fv(perspLoc, false, new Float32Array(p));
 gl.uniformMatrix4fv(camLoc, false, new Float32Array(c));
}

function animate() {
    gl.clear(gl.COLOR_BUFFER_BIT);
    for (let i = 0; i < 3; i++) {
        r[i] += a[i];
    }
    activateBuffer(buf);

    //Use these 3 lines of comments to better understand how perspective works. Change values slowly and experiment with how the "look" changes. You could also try adding buttons that change these values while it is running, such as increasing the near plane or narrrowing the FOV angle
    //setUniforms(makeRotMatrix(r[0],r[1],r[2]),makeShiftMatrix(sh[0],sh[1],sh[2]),m4(),makeShiftMatrix(-cs[0], -cs[1], -cs[2]));
    //setUniforms(makeRotMatrix(r[0],r[1],r[2]),makeShiftMatrix(sh[0],sh[1],sh[2]),makePerspMatrix(1,100,1,1),makeShiftMatrix(-cs[0], -cs[1], -cs[2]));
    setUniforms(makeRotMatrix(r[0],r[1],r[2]),makeShiftMatrix(sh[0],sh[1],sh[2]),makeFOVMatrix(0.0001,100,30,1),makeShiftMatrix(-cs[0], -cs[1], -cs[2]));
    
    gl.drawArrays(gl.TRIANGLES, 0, 6*6);
    requestAnimationFrame(animate);
}

activateBuffer(buf);
animate();
//drawWithUniform(3, gl.TRIANGLES, makeMatrix(0,0,0));