const canvas = document.querySelector('canvas');
const gl = canvas.getContext('webgl');

if (!gl) {
    throw new Error("WebGL not supported");
}

function IdMatrix() {
    return new Float32Array([
        1, 0, 0, 0,
        0, 1, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1,
    ]);
}

function translate(tx, ty, tz) {
    return new Float32Array([
        1, 0, 0, 0,
        0, 1, 0, 0,
        0, 0, 1, 0,
        tx, ty, tz, 1,
    ]);
}

function multiply(identityArray, mdl, tr) {
    let result = new Float32Array(16);

    for (let row = 0; row < 4; row++) {
        for (let col = 0; col < 4; col++) {
            result[col + row * 4] = mdl[row * 4] * tr[col] + mdl[row * 4 + 1] * tr[col + 4] + mdl[row * 4 + 2] * tr[col + 8] + mdl[row * 4 + 3] * tr[col + 12];
        }
    }

    for (let i = 0; i < 16; i++) {
        identityArray[i] = result[i];
    }

    return identityArray;
}

const vsSource = `
attribute vec3 pos;
attribute vec3 color;
varying vec3 vColor;
uniform mat4 model;

void main() {
    vColor = color;
    gl_Position = model * vec4(pos, 1.0);
}`;

const fsSource = `
precision mediump float;
varying vec3 vColor;

void main() {
    gl_FragColor = vec4(vColor, 1.0);
}`;

const vertices = new Float32Array([
    0, 0.4, 0,
    -0.3, 0, 0,
    0.3, 0, 0,
]);

const colorData = new Float32Array([
    1, 0, 0,
    0, 1, 0,
    0, 0, 1,
]);

let tx = 0;
let ty = 0;
let tz = 0;
let txIncrease = 0;
let tyIncrease = 0;

gl.clearColor(1, 0, 1, 1);
gl.clear(gl.COLOR_BUFFER_BIT);

const vertexShader = gl.createShader(gl.VERTEX_SHADER);
gl.shaderSource(vertexShader, vsSource);
gl.compileShader(vertexShader);
if (!gl.getShaderParameter(vertexShader, gl.COMPILE_STATUS)) {
    console.error(gl.getShaderInfoLog(vertexShader));
}

const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(fragmentShader, fsSource);
gl.compileShader(fragmentShader);
if (!gl.getShaderParameter(fragmentShader, gl.COMPILE_STATUS)) {
    console.error(gl.getShaderInfoLog(fragmentShader));
}

const buffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

const colorBuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
gl.bufferData(gl.ARRAY_BUFFER, colorData, gl.STATIC_DRAW);

const program = gl.createProgram();
gl.attachShader(program, vertexShader);
gl.attachShader(program, fragmentShader);
gl.linkProgram(program);
gl.useProgram(program);

let identityArray = IdMatrix();

document.onkeydown = function (event) {
    switch (event.key) {
        case 'ArrowRight':
            txIncrease = 0.01;
            tx+=0.5;
            break;
        case 'ArrowLeft':
            txIncrease = -0.01;
            break;
        case 'ArrowUp':
            tyIncrease = 0.01;
            break;
        case 'ArrowDown':
            tyIncrease = -0.01;
            break;
    }
}

function draw() {
    identityArray = multiply(identityArray, IdMatrix(), translate(tx, ty, tz));

    const positionLocation = gl.getAttribLocation(program, 'pos');
    gl.uniformMatrix4fv(gl.getUniformLocation(program, 'model'), false, identityArray);
    gl.enableVertexAttribArray(positionLocation);
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.vertexAttribPointer(positionLocation, 3, gl.FLOAT, false, 0, 0);

    const colorLocation = gl.getAttribLocation(program, 'color');
    gl.enableVertexAttribArray(colorLocation);
    gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
    gl.vertexAttribPointer(colorLocation, 3, gl.FLOAT, false, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);

    tx += txIncrease;
    ty += tyIncrease;
    
    // Reset the increments to stop continuous movement
    //txIncrease = 0;
   // tyIncrease = 0;

    gl.drawArrays(gl.TRIANGLES, 0, vertices.length / 3);

    window.requestAnimationFrame(draw);
}

draw();
