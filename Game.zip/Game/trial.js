const canvas = document.querySelector(`canvas`);
const gl = canvas.getContext(`webgl`);

if(!gl){
    throw new error("webgl not supported");

}

const vertices = new Float32Array([

    -0.5,0,
     0,1,
     0.5,0,
]);

const colorData = new Float32Array([

    1,0,0,
    0,1,0,
    0,0,1,
]);

const buffer =  gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
gl.bufferData(gl.ARRAY_BUFFER,vertices,gl.STATIC_DRAW);

const colorBuffer =  gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER,colorBuffer);
gl.bufferData(gl.ARRAY_BUFFER,colorData,gl.STATIC_DRAW);

const vsSource = `
attribute vec2 pos;
attribute vec3 color;
varying vec3 vColor;
uniform float k;
uniform float j;
void main(){

    vColor =  color;
    gl_Position =  vec4(pos*0.3 ,0,1)+vec4(k,j,0,0);
     
}`;
    k=0.5;
const fsSource=`
precision mediump float;
varying vec3 vColor;

void main(){
    gl_FragColor = vec4(vColor,1);
}`;


const vertexShader =  gl.createShader(gl.VERTEX_SHADER);
gl.shaderSource(vertexShader,vsSource);
gl.compileShader(vertexShader);

const fragmentShader =  gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(fragmentShader,fsSource);
gl.compileShader(fragmentShader);

const program  =  gl.createProgram();
gl.attachShader(program,vertexShader);
gl.attachShader(program,fragmentShader);
gl.linkProgram(program);
gl.useProgram(program);

const moveX =  gl.getUniformLocation(program,`k`);
const moveY =  gl.getUniformLocation(program,`j`)


const positionLocation = gl.getAttribLocation(program,`pos`);
gl.enableVertexAttribArray(positionLocation);
gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
gl.vertexAttribPointer(positionLocation,2,gl.FLOAT,false,0,0);


const colorLocation =  gl.getAttribLocation(program,`color`);
gl.enableVertexAttribArray(colorLocation);
gl.bindBuffer(gl.ARRAY_BUFFER,colorBuffer);
gl.vertexAttribPointer(colorLocation,3,gl.FLOAT,false,0,0);

gl.clear(gl.COLOR_BUFFER_BIT);
let k1 = -0.5;
let j1 = -0.5;
let x_speed = 0.01;
let y_speed = 0.01;
draw();
function draw(){

    k1=k1+x_speed;
    j1=j1+y_speed;
gl.uniform1f(moveX,k1);
gl.uniform1f(moveY,j1);

console.log(k1);
if(k1>=0.7||k1<=-0.8){
    x_speed*=-1;
}
if(j1>=0.5||j1<-1){
    y_speed*=-1;
}
// Add event listeners for keydown and keyup events
document.addEventListener('keydown', function(event) {
    if (event.key === 'ArrowRight') {
        x_speed = Math.abs(x_speed); // Make x_speed positive
    } else if (event.key === 'ArrowLeft') {
        x_speed = -Math.abs(x_speed); // Make x_speed negative
    } else if (event.key === 'ArrowDown') {
        y_speed = -Math.abs(y_speed); // Make y_speed positive
    } else if (event.key === 'ArrowUp') {
        y_speed = Math.abs(y_speed); // Make y_speed negative
    }
});


gl.drawArrays(gl.TRIANGLES,0,3);
window.requestAnimationFrame(draw);
}