const canvas = document.querySelector('canvas');
const gl = canvas.getContext('webgl');

const vertices = new Float32Array([ 
   
    0,-0.4,  
    -0.5,0.3,
    -0.3,0.5,
     0.3,0.5,
     0.5,0.3,
     0.5,0.1

]);

const PointsVertices = new Float32Array([ 
    0,-0.4,  
    -0.5,0.3,
    -0.3,0.5,
     0.3,0.5,
     0.5,0.3,
     0.5,0.1
]);

const lineVertices = new Float32Array([

    0,-0.4,  
   -0.5,0.3,
   -0.3,0.5,
    0.3,0.5,
    0.5,0.3,
    0.5,0.1,
    0,-0.4,
   -0.3,0.5,
    0.3,0.5,
    0,-0.4,
    0.5,0.3
     
     
   
    



]);




const vsSource = `
attribute vec2 pos;

uniform mat4 rotationMatrix;
void main(){
    gl_Position = rotationMatrix *vec4(pos,0,1.0);
    float c;
    float s;


}`;

const fsSource = `
void main(){
    gl_FragColor = vec4(1, 0, 0, 1);
}`;

const pointsFsSource = `
void main(){
    gl_FragColor = vec4(1, 0, 0, 1);
    gl_PointSize = 20.0;
}`;

const buffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

let angle = 0 ;
s = Math.sin(angle);
    c = Math.cos(angle);
    const rotationMatrix = [
        1 ,0 ,0 ,0,
        0 ,c ,-s ,0,
        0 ,s ,c ,0,
        0 ,0 ,0 ,1,
    
    ];
const pointsBuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, pointsBuffer);
gl.bufferData(gl.ARRAY_BUFFER, PointsVertices, gl.STATIC_DRAW);

const lineBuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, lineBuffer);
gl.bufferData(gl.ARRAY_BUFFER, lineVertices, gl.STATIC_DRAW);

const vertexShader = gl.createShader(gl.VERTEX_SHADER);
gl.shaderSource(vertexShader, vsSource);
gl.compileShader(vertexShader);

const fragShader = gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(fragShader, fsSource);
gl.compileShader(fragShader);

const pointsFragShader = gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(pointsFragShader, pointsFsSource);
gl.compileShader(pointsFragShader);

const lineShader = gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(lineShader, `

void main(){ 
    gl_FragColor = vec4(0,0,0,1);
}`);
gl.compileShader(lineShader);

const program = gl.createProgram();
gl.attachShader(program, vertexShader);
gl.attachShader(program, fragShader);
gl.linkProgram(program);


const pointsProgram = gl.createProgram();
gl.attachShader(pointsProgram, vertexShader);
gl.attachShader(pointsProgram, pointsFragShader);
gl.linkProgram(pointsProgram);

const lineProgram = gl.createProgram();
gl.attachShader(lineProgram, vertexShader);
gl.attachShader(lineProgram, lineShader);
gl.linkProgram(lineProgram);

gl.clearColor(0.3, 0.5, 0.7, 1);
const rotationMatrixUniformLocation =  gl.getUniformLocation(program,'rotationMatrix');

gl.uniformMatrix4fv(rotationMatrixUniformLocation,false,rotationMatrix);

const positionLocation = gl.getAttribLocation(program, 'pos');
gl.enableVertexAttribArray(positionLocation);

const positionLocation2 = gl.getAttribLocation(pointsProgram, 'pos');
gl.enableVertexAttribArray(positionLocation2);

const positionLocation3 = gl.getAttribLocation(lineProgram, 'pos');
gl.enableVertexAttribArray(positionLocation3);

draw();

function draw(){
    let angle = 0 ;
    angle+=0.1;

    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.useProgram(program);
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);
    gl.uniformMatrix4fv(rotationMatrixUniformLocation,false,rotationMatrix);
    gl.drawArrays(gl.TRIANGLE_FAN,0 , 6);


    gl.useProgram(pointsProgram);
    gl.bindBuffer(gl.ARRAY_BUFFER, pointsBuffer);
    gl.vertexAttribPointer(positionLocation2, 2, gl.FLOAT, false, 0, 0);
    gl.uniformMatrix4fv(rotationMatrixUniformLocation,false,rotationMatrix);
    gl.drawArrays(gl.POINT, 0, 6);

    gl.useProgram(lineProgram);
    gl.bindBuffer(gl.ARRAY_BUFFER, lineBuffer);
    gl.vertexAttribPointer(positionLocation3, 2, gl.FLOAT, false, 0, 0);
    gl.uniformMatrix4fv(rotationMatrixUniformLocation,false,rotationMatrix);
    gl.drawArrays(gl.LINE_LOOP, 0, 11);

    window.requestAnimationFrame(draw);
}
