const canvas =  document.querySelector(`canvas`);
const gl =canvas.getContext(`webgl`);

if(!gl){
    throw new console.error("webgl not supported");

}
gl.clearColor(1,1,1,1);
gl.clear(gl.COLOR_BUFFER_BIT);

const vertices = new Float32Array([ 
    0,1,
    1,0,
    -1,0,

]);

const colorData =  new Float32Array([

    1,0,0,
    0,1,0,
    0,0,1
]);

const buffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
gl.bufferData(gl.ARRAY_BUFFER,vertices,gl.STATIC_DRAW);

const colorbuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER,colorbuffer);
gl.bufferData(gl.ARRAY_BUFFER,colorData,gl.STATIC_DRAW);

var vsSource =`
attribute vec2 pos;
attribute vec3 color;
varying vec3 vcolor;
uniform float x;
uniform float y;

void main(){
   // x=0.7;
  //  y=0;
    gl_Position = vec4(pos*0.25,0,1)+vec4(x,y,0,1);
    vcolor = color;
}`;

var fsSource =`
precision mediump float;
varying vec3 vcolor;
void main(){
   
    gl_FragColor=vec4(vcolor,1);
}`;





const vertexShader =  gl.createShader(gl.VERTEX_SHADER);
const fragmentShader =  gl.createShader(gl.FRAGMENT_SHADER);

gl.shaderSource(vertexShader,vsSource);
gl.shaderSource(fragmentShader,fsSource);

gl.compileShader(vertexShader);
gl.compileShader(fragmentShader);

const program = gl.createProgram();
gl.attachShader(program,vertexShader);
gl.attachShader(program,fragmentShader);
gl.linkProgram(program);
gl.useProgram(program);

  //  gl.clearColor(1, 0, 1, 1);
    gl.enable(gl.DEPTH_TEST);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.viewport(0, 0, canvas.width, canvas.height); 

gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
const positionLocation =gl.getAttribLocation(program,'pos');
gl.enableVertexAttribArray(positionLocation);
gl.vertexAttribPointer(positionLocation,2,gl.FLOAT,false,0,0);

gl.bindBuffer(gl.ARRAY_BUFFER,colorbuffer);
const colorLocation =gl.getAttribLocation(program,'color');
gl.enableVertexAttribArray(colorLocation);
gl.vertexAttribPointer(colorLocation,3,gl.FLOAT,false,0,0);


let x = 0;
let y = 0; 

let x1 = -0.3;
let y1 = 0.99; 

let increaseX =0.03;

let increaseY =0.003;

function draw(){
x = x+increaseX;
y1 = y1+increaseY;
  // console.log(x);
   console.log(y1);

   if(x>1.7){

    increaseX = -0.03;

   }

   if(x<-1.7){

    increaseX = 0.03;

   }

   if(y1>1.71){

    increaseY = -0.03;

   }

   if(y1<-2){

    increaseY = 0.03;

   }
   

gl.clear(gl.COLOR_BUFFER_BIT);

gl.uniform1f(gl.getUniformLocation(program,'x'),x);
gl.uniform1f(gl.getUniformLocation(program,'y'),y);
gl.drawArrays(gl.TRIANGLE_STRIP,0,3);


gl.uniform1f(gl.getUniformLocation(program,'x'),x1);
gl.uniform1f(gl.getUniformLocation(program,'y'),y1);
gl.drawArrays(gl.TRIANGLE_STRIP,0,3);





window.requestAnimationFrame(draw);

}

draw();