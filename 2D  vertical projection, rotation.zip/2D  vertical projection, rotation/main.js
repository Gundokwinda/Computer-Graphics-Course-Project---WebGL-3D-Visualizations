const canvas = document.querySelector( `canvas`);
const gl = canvas.getContext( `webgl`);
if(!gl){
    throw new console.error("webgl not alllowed");
}

gl.clearColor(1,0,1,1);
gl.clear(gl.COLOR_BUFFER_BIT);

const vertices = new Float32Array([
    0, 0.4,
    0.2, 0,
    -0.2, 0,
]);

const colorData= new Float32Array([
     1,0,0,
     0,1,0,
     0,0,1

]);

const vsSource = `
attribute vec2 pos;
attribute vec3 color;
varying vec3 vColor;
uniform float xMove, yMove;

void main(){
   
    gl_Position =  vec4(pos,0,1) + vec4(xMove, yMove, 0, 0);
    vColor =  color;
}`;

const fsSource =  `
    precision mediump float;
    varying vec3 vColor;
void main(){
 
    gl_FragColor = vec4(vColor,1);
}`;
const buffer =  gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
gl.bufferData(gl.ARRAY_BUFFER,vertices,gl.STATIC_DRAW);

const colorbuffer =  gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER,colorbuffer);
gl.bufferData(gl.ARRAY_BUFFER,colorData,gl.STATIC_DRAW);

const vertexShader =  gl.createShader(gl.VERTEX_SHADER);
gl.shaderSource(vertexShader,vsSource);
gl.compileShader(vertexShader);

const fragmentShader =  gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(fragmentShader,fsSource);
gl.compileShader(fragmentShader);

const program  =  gl.createProgram();
gl.attachShader(program,vertexShader);
gl.attachShader(program,fragmentShader);
gl.linkProgram(program);
gl.useProgram(program);

const positionLocation = gl.getAttribLocation(program,`pos`);
gl.enableVertexAttribArray(positionLocation);
gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
gl.vertexAttribPointer(positionLocation,2,gl.FLOAT,false,0,0);


const colorLocation = gl.getAttribLocation(program,`color`);
gl.enableVertexAttribArray(colorLocation);
gl.bindBuffer(gl.ARRAY_BUFFER,colorbuffer);
gl.vertexAttribPointer(colorLocation,3,gl.FLOAT,false,0,0);


const xuniformlocation = gl.getUniformLocation(program,`xMove`);
const yuniformlocation = gl.getUniformLocation(program, `yMove`);

let MoveX = 0;
let MoveY = 0;

let xSpeed = 0.001;
let ySpeed = 0.001;

draw();
function draw(){
    gl.clear(gl.COLOR_BUFFER_BIT);

    if(MoveX >= 0.55 || MoveX <= -0.5)
    {
        xSpeed *= -1;
    }

    if(MoveY >= 0.66 || MoveY <= -0.7)
    {
        ySpeed *= -1;
    }

    MoveX += xSpeed;
    MoveY += ySpeed;
console.log(MoveX);
console.log(MoveY);
    gl.uniform1f(xuniformlocation,MoveX);
    gl.uniform1f(yuniformlocation, MoveY);

    gl.drawArrays(gl.TRIANGLE_FAN,0,3);

    window.requestAnimationFrame(draw);

}