// Vertex shader source code
const vsSource = `
    attribute vec2 position;
    uniform vec2 translation;
    void main() {
        // Apply translation to position
        vec2 newPosition = position + translation;
        gl_Position = vec4(newPosition, 0.0, 1.0);
    }
`;

// Fragment shader source code
const fsSource = `
    void main() {
        gl_FragColor = vec4(1.0, 1.0, 0.0, 1.0);
    }
`;

// Initialize WebGL
const canvas = document.getElementById('canvas');
const gl = canvas.getContext('webgl');

if (!gl) {
    alert('Unable to initialize WebGL. Your browser may not support it.');
}

// Set clear color with fully opaque
gl.clearColor(1.0, 0.0, 0.4, 1.0);
// Clear the color buffer with specified clear color
gl.clear(gl.COLOR_BUFFER_BIT);

// Pac-Man properties
const pacmanRadius = 0.2; // Smaller radius

// Define vertices for Pac-Man (circle)
const pacmanVertices = [0, 0];

for (let angle = 0.5; angle <= 2 * Math.PI; angle += (2 * Math.PI) / 32) {
    const x = Math.cos(angle) * pacmanRadius; // x coordinate
    const y = Math.sin(angle) * pacmanRadius; // y coordinate
    pacmanVertices.push(x, y);
}

const vertices = new Float32Array(pacmanVertices);

// Convert vertices to WebGL buffers
const pacmanBuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, pacmanBuffer);
gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

// Create shaders
const vertexShader = gl.createShader(gl.VERTEX_SHADER);
gl.shaderSource(vertexShader, vsSource);
gl.compileShader(vertexShader);

const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(fragmentShader, fsSource);
gl.compileShader(fragmentShader);

// Create shader program
const shaderProgram = gl.createProgram();
gl.attachShader(shaderProgram, vertexShader);
gl.attachShader(shaderProgram, fragmentShader);
gl.linkProgram(shaderProgram);
gl.useProgram(shaderProgram);

// Get attribute location and enable it
const positionAttributeLocation = gl.getAttribLocation(shaderProgram, 'position');
gl.enableVertexAttribArray(positionAttributeLocation);

// Get the location of the translation uniform in the shader
const translationUniformLocation = gl.getUniformLocation(shaderProgram, 'translation');

let pacmanX = 0;
let pacmanY = 0;
let pacmanSpeed = 0.09;

// Start the render loop
render();

// Main render loop
function render() {
    gl.clear(gl.COLOR_BUFFER_BIT);

    // Set the translation in the shader
    gl.uniform2f(translationUniformLocation, pacmanX, pacmanY);

    // Draw Pac-Man
    gl.bindBuffer(gl.ARRAY_BUFFER, pacmanBuffer);
    gl.vertexAttribPointer(positionAttributeLocation, 2, gl.FLOAT, false, 0, 0);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, vertices.length / 2);

    // Call render again
    requestAnimationFrame(render);
}

// Event listeners for arrow key movement
document.addEventListener('keydown', handleKeyDown);

function handleKeyDown(event) {
    switch (event.key) {
        case 'ArrowRight':
            pacmanX += pacmanSpeed;
            break;
        case 'ArrowLeft':
            pacmanX -= pacmanSpeed;
            break;
        case 'ArrowUp':
            pacmanY += pacmanSpeed;
            break;
        case 'ArrowDown':
            pacmanY -= pacmanSpeed;
            break;
    }
}
