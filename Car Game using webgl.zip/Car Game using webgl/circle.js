const canvas = document.querySelector('canvas');
const gl = canvas.getContext('webgl');

if (!gl) {
  throw new Error("WebGL not available/supported");
}

// Triangle data
const triangleVertices = new Float32Array([ 
  -0.9, 0.5,  // Top left
  0.9, 0.5,  // Top right
  0.9, -0.5, // Bottom right
 -0.9, -0.5  // Bottom left
 

]);
var r =0.5;//radius of a full circle
let model = createmat4();
let view = createmat4();
let projection = createmat4();
let start = true;
let image = document.getElementById("Car1");
const triangleColors = new Float32Array([
  0, 1, 0,
  0, 1, 0,
  0, 1, 0,
  0, 1, 0,
  0, 1, 0,
]);

function createmat4(){		
	return	new Float32Array([
	1,0,0,0,
	0,1,0,0,
	0,0,1,0,
	0,0,0,1
	]);
	}
var texCoords = new Float32Array([
  1, 1,
	1, 0,
	0, 1,
	0, 1,
	1, 0,
	0, 0,
]);
// Circle data
const circleVertices = [];
const deltaP = (2 * Math.PI) / 30;
const arch = 2 * Math.PI;


for (let p = 0; p <= arch; p += deltaP) {
  const x = r * Math.cos(p);
  const y = r * Math.sin(p);
  circleVertices.push(x, y);
}

// Combined buffer data
const vertices = new Float32Array([...triangleVertices, ...circleVertices]);
const colors = new Float32Array([...triangleColors, ...new Array(circleVertices.length / 2 * 3).fill(0.6, 0.7, 0.5)]);

// Create buffers
const vertexBuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);


const texCoordBuffer = webgl.createBuffer(); 
webgl.bindBuffer(webgl.ARRAY_BUFFER, texCoordBuffer);
webgl.bufferData(webgl.ARRAY_BUFFER, texCoords,webgl.STATIC_DRAW); 

const texturebuffer = webgl.createTexture();
  webgl.bindTexture(webgl.TEXTURE_2D,texturebuffer); 
  /*  if your dimensions are not powers of two then comment out line 143 and uncomment 137-140	*/
	webgl.texParameteri(webgl.TEXTURE_2D, webgl.TEXTURE_MAG_FILTER, webgl.LINEAR);
	webgl.texParameteri(webgl.TEXTURE_2D, webgl.TEXTURE_MIN_FILTER, webgl.LINEAR);
	webgl.texParameteri(webgl.TEXTURE_2D, webgl.TEXTURE_WRAP_S, webgl.CLAMP_TO_EDGE);
	webgl.texParameteri(webgl.TEXTURE_2D, webgl.TEXTURE_WRAP_T, webgl.CLAMP_TO_EDGE);
	
	webgl.texImage2D(webgl.TEXTURE_2D,0,webgl.RGBA,webgl.RGBA,webgl.UNSIGNED_BYTE,image);

const colorBuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
gl.bufferData(gl.ARRAY_BUFFER, colors, gl.STATIC_DRAW);

// Shader sources
const vsSource = `
  attribute vec3 pos;

  uniform float x;
  uniform float y;
  attribute vec2 vtexture ;
	attribute vec3 pos;
	varying vec2 fragtexture;
	uniform mat4 m;
	uniform mat4 v;
	uniform mat4 p;
  void main(){
   // gl_Position = vec4(pos * 0.25 + vec2(x, y), 0, 1);
    gl_Position = p*v*m*vec4(pos * 0.25 + vec2(x, y), 0, 1);  
    fragtexture = vtexture;
    vcolor = color;
  }
`;
gl.compileShader(vertexShader);

const fsSource = `
  precision mediump float;
  varying vec2 fragtexture;
	uniform sampler2D fragsampler;
  
  void main(){
    gl_FragColor = texture2D(fragsampler,fragtexture);
  }
`;

// Compile shaders
const vertexShader = gl.createShader(gl.VERTEX_SHADER);
gl.shaderSource(vertexShader, vsSource);
gl.compileShader(vertexShader);

const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(fragmentShader, fsSource);
gl.compileShader(fragmentShader);

// Create program
const program = gl.createProgram();
gl.attachShader(program, vertexShader);
gl.attachShader(program, fragmentShader);
gl.linkProgram(program);
gl.useProgram(program);
webgl.enable(webgl.DEPTH_TEST);

// Get attribute locations
const positionLocation = gl.getAttribLocation(program, 'pos');


// Bind vertex buffer
gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);
gl.enableVertexAttribArray(positionLocation);


const textureLocation = webgl.getAttribLocation(program, `vtexture`);
webgl.enableVertexAttribArray(textureLocation);    
webgl.bindBuffer(webgl.ARRAY_BUFFER, texCoordBuffer);
webgl.vertexAttribPointer(textureLocation, 2, webgl.FLOAT, false, 0, 0);

const modelLocation = 	webgl.getUniformLocation(program, `m`);
const viewLocation = 	webgl.getUniformLocation(program, `v`);
const projLocation = 	webgl.getUniformLocation(program, `p`);

translate(model, model, [0, 0, -1]);
translate(view, view, [0, 0, 1]);
invert(view, view);


// Animation variables
let x1 = 0;
let y1 = 0;
let increaseX = 0.07;
let increaseY = 0.07;

// Draw function
function draw() {
  //x1 += increaseX;
 // y1 += increaseY;
 webgl.clear(webgl.COLOR_BUFFER_BIT);
 webgl.bindTexture(webgl.TEXTURE_2D,texturebuffer);
webgl.activeTexture(webgl.TEXTURE0);

if(start){	rotateY(model, model,0.01);}
	webgl.uniformMatrix4fv(projLocation, false, projection);
	webgl.uniformMatrix4fv(viewLocation, false, view);
	webgl.uniformMatrix4fv(modelLocation, false, model);
	
  gl.clear(gl.COLOR_BUFFER_BIT);
  gl.uniform1f(gl.getUniformLocation(program, 'x'), x1);
  gl.uniform1f(gl.getUniformLocation(program, 'y'), y1);
  gl.drawArrays(gl.TRIANGLE_FAN,0, triangleVertices.length/4 );
  gl.drawArrays(gl.TRIANGLE_FAN, 0, circleVertices.length);
    window.requestAnimationFrame(draw);

}
function stopstart(){
  start  ^= true; //toggling using xor gate from Dig 1 

 }




  if (x1 > 0.95|| x1 <= -0.95) {
    increaseX *= -1;
  }

  if (y1 >= 0.9 || y1 <= -0.9) {
    increaseY *= -1;
  }

 console.log(x1);
 console.log(y1);
 

  document.onkeydown = function(event) {
    if (event.key === 'ArrowRight') {
      x1 += increaseX;
    } else if (event.key === 'ArrowLeft') {
      x1 -= increaseX;
    } else if (event.key === 'ArrowUp' && y1 <= 0.9) {
      y1 += increaseY;
    } else if (event.key === 'ArrowDown') {
      y1 -= increaseY;
    }
  
  
    }




 


draw();
