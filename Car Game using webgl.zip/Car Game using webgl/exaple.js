const canvas = document.querySelector('canvas');
const gl = canvas.getContext('webgl');

document.getElementById('restartButton').addEventListener('click', function() {
  window.location.reload();
});

if (!gl) {
  throw new Error("WebGL not available/supported");
}

// Triangle data
const triangleVertices = new Float32Array([ 
  -0.4, 1,  // Top left
  0.4, 1,   // Top right
  0.4, -1,  // Bottom right
 -0.4, -1   // Bottom left
]);

const roadVertices = new Float32Array([

]);

const texCoords = new Float32Array([
    0, 1, // Top left
    1, 1, // Top right
    1, 0, // Bottom right
    0, 0  // Bottom left
]);

const newRectVertices = new Float32Array([
  -0.4, -0.8, // Top left
   0.4, -0.8, // Top right
   0.4, -1.0, // Bottom right
  -0.4, -1.0  // Bottom left
]);

const newRectTexCoords = new Float32Array([
  0, 1, // Top left
  1, 1, // Top right
  1, 0, // Bottom right
  0, 0  // Bottom left
]);

// Combined buffer data without circle
const vertices = new Float32Array([...triangleVertices]);
const texCoord = new Float32Array([...texCoords]);

// Create buffers
const vertexBuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

const texCoordBuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, texCoordBuffer);
gl.bufferData(gl.ARRAY_BUFFER, texCoord, gl.STATIC_DRAW);



// Load texture
const texture = gl.createTexture();
gl.bindTexture(gl.TEXTURE_2D, texture);

const texture2 = gl.createTexture();
gl.bindTexture(gl.TEXTURE_2D, texture2);

const texture3 = gl.createTexture();
gl.bindTexture(gl.TEXTURE_2D, texture3);

const texture4 = gl.createTexture();
gl.bindTexture(gl.TEXTURE_2D, texture4);
const texture5 = gl.createTexture();
gl.bindTexture(gl.TEXTURE_2D, texture5);


const image = new Image();
const image2 = new Image();
const image3 = new Image();
const image4 = new Image();
const image5 = new Image();



image.onload = function() {
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
  gl.generateMipmap(gl.TEXTURE_2D);

  
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
};

image2.onload = function() {
  gl.bindTexture(gl.TEXTURE_2D, texture2);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image2);
  gl.generateMipmap(gl.TEXTURE_2D);
  
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
};

 
image3.onload = function() {
  gl.bindTexture(gl.TEXTURE_2D, texture3);
  //gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image3);
  gl.generateMipmap(gl.TEXTURE_2D);
  
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
}; 



image4.onload = function() {
  gl.bindTexture(gl.TEXTURE_2D, texture4);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image4);
  gl.generateMipmap(gl.TEXTURE_2D);
  
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
}; 



image5.onload = function() {
  gl.bindTexture(gl.TEXTURE_2D, texture5);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image5);
  gl.generateMipmap(gl.TEXTURE_2D);
  
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
}; 


image.src =  'mustang.jpg';
image2.src = 'yellow.png';
image3.src = 'silver.jpg';
image4.src = 'porche.jpg';
image5.src = 'porche.jpg';

gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
gl.texImage2D(gl.TEXTURE_2D, 1, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image2);
gl.texImage2D(gl.TEXTURE_2D,2, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image3);
gl.texImage2D(gl.TEXTURE_2D, 3, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image4);
gl.texImage2D(gl.TEXTURE_2D, 4, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image5);
// Shader sources
const vsSource = `
  attribute vec2 position;
  attribute vec2 texCoord;
  varying vec2 vTexCoord;
  uniform float x;
  uniform float y;
  void main() {
    gl_Position = vec4(position * 0.2+ vec2(x, y), 0, 1);
    vTexCoord = texCoord;
  }
`;

const fsSource = `
  precision mediump float;
  varying vec2 vTexCoord;
  uniform sampler2D texture;
  uniform sampler2D texture1;
  uniform sampler2D texture2;
  uniform sampler2D texture3;
  uniform sampler2D texture4;
  uniform sampler2D texture5;
  void main() {
    gl_FragColor = texture2D(texture, vec2(vTexCoord.x, 1.0 - vTexCoord.y));
    
  }
`;

// Compile shaders
const vertexShader = gl.createShader(gl.VERTEX_SHADER);
gl.shaderSource(vertexShader, vsSource);
gl.compileShader(vertexShader);

const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(fragmentShader, fsSource);
gl.compileShader(fragmentShader);

// Create program
const program = gl.createProgram();
gl.attachShader(program, vertexShader);
gl.attachShader(program, fragmentShader);
gl.linkProgram(program);
gl.useProgram(program);

// Get attribute locations
const positionLocation = gl.getAttribLocation(program, 'position');
const texCoordLocation = gl.getAttribLocation(program, 'texCoord');



// Bind vertex buffer
gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);
gl.enableVertexAttribArray(positionLocation);


// Bind texture coordinate buffer
gl.bindBuffer(gl.ARRAY_BUFFER, texCoordBuffer);
gl.vertexAttribPointer(texCoordLocation, 2, gl.FLOAT, false, 0, 0);
gl.enableVertexAttribArray(texCoordLocation);

// Set clear color
gl.clearColor(1, 1, 1, 1);

// Set viewport
gl.viewport(0, 0, canvas.width, canvas.height);

// Animation variables
let x1 = 0.4;
let y1 = -1.6;
let increaseX = 0.009;
let increaseY =0.01;


// Animation variables for car 2
let x2 = 0;
let y2 = 1.3;
let increaseX2 =0.009;
let increaseY2 =0.01;

// Animation variables for car 3
let x3 = 0.8;
let y3 = 1.2;
let increaseX3 =0.009;
let increaseY3 =0.01; 

let x5 = -0.2;
let y5= -1.5;
let increaseX5 =0.009;
let increaseY5 = 0.01; 

// Animation variables for car 4
let x4 = -0.6;
let y4 = -0.8;
let increaseX4 =0.01;
let increaseY4= 0.0000000001; 
 
 
const whiteColor = [1, 1, 1, 1]; // White color
const redColor = [1, 0, 0, 1]; // Red color
let isWhite = true; // Flag to track current color state




let collisionOccurred = false;
let startTime = null;
let isGameOver = false;
let elapsedTime = 0;

function checkGameOver() {
  // Check if car 4 collided with car 1,2 or 4
  if (Math.abs(x1 - x2) < 1 && Math.abs(y1 - y2) < 0.1) {
    isGameOver = true;
  }
}

function drawBackground() {
  if (isGameOver) {
    gl.clearColor(1, 1, 1 ,1); // Red background for game over
  } else {
    gl.clearColor(1, 1, 0, 1); // Black background during gameplay
  }
}
function updateScore() {
  if (!isGameOver) {
    elapsedTime = Date.now() - startTime;
    const seconds = Math.floor(elapsedTime / 100);
    // Update scoreboard with elapsed time
    document.getElementById('scoreboard').innerText = `Score: ${seconds} ms`;
  }
}

// Draw function
function draw(timestamp) {

  checkGameOver();
  drawBackground();
  updateScore();

  // Update positions
  if (!collisionOccurred) {
    // Update positions only if no collision has occurred
    y1 += increaseY;
    y2 -= increaseY2;
    y3 -= increaseY3;
    y4 += increaseY4;
    y5 += increaseY5;
  }
  if (
    Math.abs(x1 - x4) < 0.1 && // Check x-axis overlap
    Math.abs(y1 - y4) < 0.1 ||   // Check y-axis overlap
    Math.abs(x2 - x4) < 0.1 && 
    Math.abs(y2 - y4) < 0.1 || 
    Math.abs(x3 - x4) < 0.1&& 
    Math.abs(y3 - y4) < 0.1 
    
  ) {
    // Set collision flag to true
    collisionOccurred = true;
    
    // Stop all cars by setting their increase variables to 0
    increaseX = 0;
    increaseY = 0;
    increaseX2 = 0;
    increaseY2 = 0;
    increaseX3 = 0;
    increaseY3 = 0;
    increaseX4 = 0;
    increaseY4 = 0;
  }
  let blinkDuration = 10; // 10 seconds in milliseconds
  let blinkStartTime = 0; // Variable to store the start time of blinking
  

  if (blinkStartTime === 8) {
    blinkStartTime = timestamp;
  }

  // Calculate time elapsed since the start of blinking
  const elapsedTime = timestamp + blinkStartTime;

  // Collision detection for car1
  if (
    Math.abs(x1 - x4) < 0.1 && // Check x-axis overlap
    Math.abs(y1 - y4) < 0.1    // Check y-axis overlap
   
  ) {
   
    
    increaseX = 0;
    increaseY = 0;
    increaseX2 = 0;
    increaseY2 = 0;
    increaseX3 = 0;
    increaseY3 = 0;
    increaseX4 = 0;
    increaseY4 = 0;
    // Set clear color to red
    gl.clearColor(1, 0, 0, 1);
    isWhite = !isWhite; // Toggle color state
    const clearColor = isWhite ? whiteColor : redColor; // Select color based on state
    gl.clearColor(...clearColor); // Set clear color
    
    window.location.reload();
  
  } else if (
    //collision detection for car2
    Math.abs(x2 - x4) < 0.1 && // Check x-axis overlap
    Math.abs(y2 - y4) < 0.1    // Check y-axis overlap
    
  ) {
    // Car4 collided with Car2, make Car4 disappear
    //x4 = 10; // Move Car4 off-screen
   // y4 = 10; // Move Car4 off-screen
    //y4 -= gl.uniform1f(gl.getUniformLocation(program, 'y'), y4);
    
    y2 = 1.3;
    x1 = 1.3;
    x1 = 1.3;
    y1 = 1.3;
   
 
    // Set clear color to red
    //gl.clearColor(1, 0, 1, 1);
    isWhite = !isWhite; // Toggle color state
    const clearColor = isWhite ? whiteColor : redColor; // Select color based on state
    gl.clearColor(...clearColor); // Set clear color
    window.location.reload();
  } else if (
    //collision detection for car3
    Math.abs(x3 - x4) < 0.1&& // Check x-axis overlap
    Math.abs(y3 - y4) < 0.1   // Check y-axis overlap
  ) {
    // Car4 collided with Car3, make Car4 disappear
    x4 = 10; // Move Car4 off-screen
    y4 = 10; // Move Car4 off-screen
    y4 -= gl.uniform1f(gl.getUniformLocation(program, 'y'), y3);
    // Set clear color to red
    //gl.clearColor(0, 0, 0, 1);
    isWhite = !isWhite; // Toggle color state
    const clearColor = isWhite ? whiteColor : redColor; // Select color based on state
    gl.clearColor(...clearColor); // Set clear color
    window.location.reload();
  } 
  else {
    gl.clearColor(...whiteColor); // Set clear color to white
    
  }

// Add event listener to pause button
document.getElementById('pauseButton').addEventListener('click', function() {
  increaseX = 0;
  increaseY = 0;
  increaseX2 = 0;
  increaseY2 = 0;
  increaseX3 = 0;
  increaseY3 = 0;
  increaseX4 = 0;
  increaseY4 = 0;
  isPaused = !isPaused; // Toggle the paused state
});

  
  if (y2 < -0.8 ) {
    x1 = -0.8;
    x2 =  0.22;
    x3 =  0.9;
    x3 =  0.9;
    y1*=-1;
    y2*=-1;
    y3*-1;
    x3 = -0.5;
   
     
  }

    
  if (y1 < -0.9 ) {

    x1 = -0.8;
    x2 =  0.22;
    x3 = -0.5;
    
 }
 //
   
 if (y3 < -0.9 ) {
    x1 = -0.1;
    x2 =  0.9;
    x3 = -0.8;
}
if (y4 > 0.9 ) {
    x4 = -0.8;


   y4*=-1.5;
}

if (x4 >= 0.8 || x4<= -0.8) {
x4 =0;
}
  // Clear canvas
  gl.clear(gl.COLOR_BUFFER_BIT);

  // Draw cars
  //Car1
  gl.uniform1f(gl.getUniformLocation(program, 'x'), x1);
  gl.uniform1f(gl.getUniformLocation(program, 'y'), y1);
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);

  //Car2
  gl.uniform1f(gl.getUniformLocation(program, 'x'), x2);
  gl.uniform1f(gl.getUniformLocation(program, 'y'), y2);
  gl.bindTexture(gl.TEXTURE_2D, texture2);
  gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);

  //Car3
  gl.uniform1f(gl.getUniformLocation(program, 'x'), x3);
  gl.uniform1f(gl.getUniformLocation(program, 'y'), y3);
  gl.bindTexture(gl.TEXTURE_2D, texture3);
 // gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);

  //Car4
  gl.uniform1f(gl.getUniformLocation(program, 'x'), x4);
  gl.uniform1f(gl.getUniformLocation(program, 'y'), y4);
  gl.bindTexture(gl.TEXTURE_2D, texture4);
  gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);

  
  //Car5
  gl.uniform1f(gl.getUniformLocation(program, 'x'), x5);
  gl.uniform1f(gl.getUniformLocation(program, 'y'), y5);
  gl.bindTexture(gl.TEXTURE_2D, texture5);
  gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);

  gl.uniform1f(gl.getUniformLocation(program, 'x'), x2);
  gl.uniform1f(gl.getUniformLocation(program, 'y'), y5);
  gl.bindTexture(gl.TEXTURE_2D, texture3);
  gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);

  gl.uniform1f(gl.getUniformLocation(program, 'x'), x2);
  gl.uniform1f(gl.getUniformLocation(program, 'y'), y5);
  gl.bindTexture(gl.TEXTURE_2D, texture2);
  gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);

  gl.uniform1f(gl.getUniformLocation(program, 'x'), x3);
  gl.uniform1f(gl.getUniformLocation(program, 'y'), y5);
  gl.bindTexture(gl.TEXTURE_2D, texture2);
  gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);

  

  checkGameOver();
  drawBackground();

  // If game over, stop drawing cars
  if (!isGameOver) {
     gl.clear(1,0,0,1);
  }
  window.requestAnimationFrame(draw);
}
// Set a flag for each arrow key
let arrowRightPressed = false;
let arrowLeftPressed = false;
let arrowUpPressed = false;
let arrowDownPressed = false;

// Add event listeners for keydown and keyup events
document.addEventListener('keydown', function(event) {
  if (event.key === 'ArrowRight') {
    arrowRightPressed = true;
  } else if (event.key === 'ArrowLeft') {
    arrowLeftPressed = true;
  } else if (event.key === 'ArrowUp') {
    arrowUpPressed = true;
  } else if (event.key === 'ArrowDown') {
    arrowDownPressed = true;
  }
});

document.addEventListener('keyup', function(event) {
  if (event.key === 'ArrowRight') {
    arrowRightPressed = false;
  } else if (event.key === 'ArrowLeft') {
    arrowLeftPressed = false;
  } else if (event.key === 'ArrowUp') {
    arrowUpPressed = false;
  } else if (event.key === 'ArrowDown') {
    arrowDownPressed = false;
  }
});

// Update car position based on pressed keys
function updateCarPosition() {
  if (arrowRightPressed) {
    x4 += increaseX4;
  } 
  if (arrowLeftPressed) {
    x4 -= increaseX4;
  }
  if (arrowUpPressed) {
    y4 += 0.01;
  }
  if (arrowDownPressed) {
    y4 -= 0.01;
  }
  
  // Repeat the function to keep the car moving
  requestAnimationFrame(updateCarPosition);
}

// Start updating the car position
updateCarPosition();

canvas.addEventListener('mousemove', function(event) {
  const rect = canvas.getBoundingClientRect();
  const mouseX = event.clientX - rect.left;
  const mouseY = event.clientY - rect.top;

  // Normalize mouse coordinates to range [-1, 1]
  const normalizedX = (mouseX / canvas.width) * 2 - 1;
  const normalizedY = ((canvas.height - mouseY) / canvas.height) * 2 - 1;

  // Update car positions based on mouse position
  x4 = normalizedX * 0.9; // Adjust the scaling factor as neededs
  y4 = normalizedY * 0.9;
});
function startTimer() {
  if (startTime === null) {
    startTime = Date.now();
  }
}
draw();
startTimer(); 