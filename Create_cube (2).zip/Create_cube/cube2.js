const canvas = document.querySelector('canvas');
const gl = canvas.getContext('webgl');

const vertices = new Float32Array([
      //front square
    1, 1, 1,              
    -1, 1, 1,
    -1, -1, 1,
    1, 1, 1,
    -1, -1, 1,
    1, -1, 1,
    //back square
    1, 1, -1,
    -1, 1, -1,
    -1, -1, -1,
    
    1, 1, -1,
    -1, -1, -1,
    1, -1, -1,
    //right side
    1, 1, -1,
    1, 1, 1,
    1, -1, 1,
    
    1, 1, -1,
    1, -1, 1,
    1, -1, -1,
    //left side
    -1, 1, -1,
    -1, 1, 1,
    -1, -1, 1,
    -1, 1, -1,
    -1, -1, 1,
    -1, -1, -1,
    //top side
    1, 1, -1,
    -1, 1, -1,
    -1, 1, 1,
    1, 1,-1,
    -1, 1, 1,
     1, 1, 1,
    //bottom side
    1, -1, -1,
    -1, -1, -1,
    -1, -1, 1,
    1, -1, -1,
    -1, -1, 1,
    1, -1, 1
]);

const buffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

const vsSource = `
attribute vec3 pos;
attribute vec3 color;
varying vec3 vColor;
uniform float angle;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;

void main() {
    float s = sin(angle);
    float c = cos(angle);
    mat3 rotateX = mat3(
        1.0, 0.0, 0.0,
        0.0, c, -s,
        0.0, s, c
    );

    mat3 rotateY = mat3(
        c, 0.0, s,
        0.0, 1.0, 0.0,
        -s, 0.0, c
    );

    mat3 rotation = rotateX * rotateY;

    vec3 rotatedPos = rotation * pos;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(rotatedPos, 1.0);
    vColor = color;
}
`;

const fsSource = `
precision mediump float;
varying vec3 vColor;
void main() {
    gl_FragColor = vec4(vColor, 1.0);
}
`;

const vertexShader = gl.createShader(gl.VERTEX_SHADER);
gl.shaderSource(vertexShader, vsSource);
gl.compileShader(vertexShader);

const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(fragmentShader, fsSource);
gl.compileShader(fragmentShader);

const program = gl.createProgram();
gl.attachShader(program, vertexShader);
gl.attachShader(program, fragmentShader);
gl.linkProgram(program);
gl.useProgram(program);

const positionLocation = gl.getAttribLocation(program, 'pos');
gl.enableVertexAttribArray(positionLocation);
gl.vertexAttribPointer(positionLocation, 3, gl.FLOAT, false, 0, 0);

const colorLocation = gl.getAttribLocation(program, 'color');
gl.enableVertexAttribArray(colorLocation);
gl.vertexAttribPointer(colorLocation, 3, gl.FLOAT, false, 0, 0);

const modelViewMatrix = mat4.create();
const projectionMatrix = mat4.create();
mat4.perspective(projectionMatrix, 45 * Math.PI / 180, canvas.width / canvas.height, 0.1, 100.0);

const modelViewMatrixLocation = gl.getUniformLocation(program, 'modelViewMatrix');
const projectionMatrixLocation = gl.getUniformLocation(program, 'projectionMatrix');

gl.uniformMatrix4fv(projectionMatrixLocation, false, projectionMatrix);

let angle = 0;

function draw() {
    gl.clearColor(1, 0, 1, 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    
    mat4.identity(modelViewMatrix);
    mat4.translate(modelViewMatrix, modelViewMatrix, [0.0, 0.0, -6.0]);
    mat4.rotateY(modelViewMatrix, modelViewMatrix, angle);
    mat4.rotateX(modelViewMatrix, modelViewMatrix, angle * 0.5);

    gl.enable(gl.DEPTH_TEST);
    gl.uniformMatrix4fv(modelViewMatrixLocation, false, modelViewMatrix);
    gl.uniform1f(gl.getUniformLocation(program, 'angle'), angle);

    gl.drawArrays(gl.TRIANGLES, 0, vertices.length / 3);
    angle += 0.01;
    requestAnimationFrame(draw);
}

draw();
