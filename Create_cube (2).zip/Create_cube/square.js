const canvas = document.querySelector(`canvas`);
const gl = canvas.getContext(`webgl`);

const vertices = new Float32Array([
           0.2,0.4,
           0.2,0,
           -0.2,0.4,
           -0.2,0,
           
]);

var buffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
gl.bufferData(gl.ARRAY_BUFFER,vertices,gl.STATIC_DRAW);


gl.clearColor(1,1,0,1);
gl.clear(gl.COLOR_BUFFER_BIT);

const vsSource =`
attribute vec2 pos;
uniform float x;
uniform float y;
 
void main(){
    
    gl_Position = vec4(pos*0.6+ vec2(x,y),0,1);
}`;

const fsSource =`

void main(){
    gl_FragColor = vec4(1,0,0,1);
}`;


const vertexShader =  gl.createShader(gl.VERTEX_SHADER);
gl.shaderSource(vertexShader,vsSource);
gl.compileShader(vertexShader);

const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(fragmentShader,fsSource);
gl.compileShader(fragmentShader);

const program =  gl.createProgram();
gl.attachShader(program,vertexShader);
gl.attachShader(program,fragmentShader);
gl.linkProgram(program);
gl.useProgram(program);

let increaseX1 = 0.01;
let increaseY1 = 0.006;
let x1 =0;
let y1 = 0;



const positionLocation = gl.getAttribLocation(program,`pos`);
gl.enableVertexAttribArray(positionLocation);
gl.vertexAttribPointer(positionLocation,2,gl.FLOAT,false,0,0);


function draw(){

console.log(x1);
console.log(y1);

if(x1 > 0.9 || x1 < -0.9){
increaseX1 *=-1;

}

if(y1 > 0.8 || y1 < -0.9){
   
    increaseY1 *=-1;
    }


    x1 += increaseX1;
    y1 += increaseY1;
gl.uniform1f(gl.getUniformLocation(program,'x'), x1);
gl.uniform1f(gl.getUniformLocation(program,'y'), y1);   
gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
gl.clearColor(1,1,0,1);
gl.drawArrays(gl.TRIANGLE_STRIP,0,4);

window.requestAnimationFrame(draw);
}
draw();