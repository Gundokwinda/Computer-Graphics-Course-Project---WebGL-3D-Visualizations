const canvas = document.querySelector('canvas');
const gl = canvas.getContext('webgl');
 
const vertices = new Float32Array([
    //front square
    1, 1, 1,
    -1, 1, 1,
    -1, -1, 1,
    1, 1, 1,
    -1, -1, 1,
    1, -1, 1,
    //back square
    1, 1, -1,
    -1, 1, -1,
    -1, -1, -1,
    1, 1, -1,
    -1, -1, -1,
    1, -1, -1,
    //right side
    1, 1, -1,
    1, 1, 1,
    1, -1, 1,
    1, 1, -1,
    1, -1, 1,
    1, -1, -1,
    //left side
    -1, 1, -1,
    -1, 1, 1,
    -1, -1, 1,
    -1, 1, -1,
    -1, -1, 1,
    -1, -1, -1,
    //top side
    1, 1, -1,
    -1, 1, -1,
    -1, 1, 1,
    1, 1,-1,
    -1, 1, 1,
     1, 1, 1,
    //bottom side
    1, -1, -1,
    -1, -1, -1,
    -1, -1, 1,
    1, -1, -1,
    -1, -1, 1,
    1, -1, 1
]);
 
var colors = [
    [1, 0, 0],
    [1, 1, 0],
    [0, 1, 1],
    [1, 0, 1],
    [0, 1, 0],
    [0, 1, 0]
]
 
var vertexbuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, vertexbuffer);
gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

 
var colorbuffer = genColor(colors, 6);
 
var vertCode = `
   attribute vec3 pos;
   attribute vec3 color;
   varying vec3 vcolor;
   uniform float angle,angle1;
   void main() { 

    //rotation by x
    
    float z = pos.z*cos(angle)-pos.y*sin(angle);
    float y = pos.y*cos(angle)+pos.z*sin(angle);
    float x = pos.x;

    //rotation by y

    float m = x;
    x = m*cos(angle1)-z*sin(angle1);
    z = z*cos(angle1)+m*sin(angle1);
    m = x;
    x = m*cos(angle1)-y*sin(angle1);
    y = y*cos(angle1)+m*sin(angle1);
    
    gl_Position = vec4(x,y,z, 2.0);
    vcolor=color;
}`;
 
var fragCode = `
precision mediump float;
varying vec3 vcolor;
void main(void) {gl_FragColor = vec4(vcolor, 1);
}`;

var vertShader = gl.createShader(gl.VERTEX_SHADER);
gl.shaderSource(vertShader, vertCode);
gl.compileShader(vertShader);
 
var fragShader = gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(fragShader, fragCode);
gl.compileShader(fragShader);
 
var shaderProgram = gl.createProgram();
gl.attachShader(shaderProgram, vertShader);
gl.attachShader(shaderProgram, fragShader);
gl.linkProgram(shaderProgram);
gl.useProgram(shaderProgram);
 
var coord = gl.getAttribLocation(shaderProgram, "pos");
gl.enableVertexAttribArray(coord);
gl.bindBuffer(gl.ARRAY_BUFFER, vertexbuffer);
gl.vertexAttribPointer(coord, 3, gl.FLOAT, false, 0, 0);

function coloring(){

var color = gl.getAttribLocation(shaderProgram, "color");
gl.bindBuffer(gl.ARRAY_BUFFER, colorbuffer);
gl.enableVertexAttribArray(color);
gl.vertexAttribPointer(color, 3, gl.FLOAT, false, 0, 0);

}

var angUniformL = gl.getUniformLocation(shaderProgram, `angle`);
var ang1UniformL = gl.getUniformLocation(shaderProgram, `angle1`);


let ang = 0;
let ang1 = 0;
var change_Color = false;

draw();
function draw() {
 
    if (change_Color) {
        colors = [];
        for(let i=0;i<6;i++){
            var r=Math.random();
            var g=Math.random();
            var b=Math.random();
 
            colors.push([r,g,b]);
        }
        colorbuffer = genColor(colors, 6);
        
        
        change_Color = false;
    }
    coloring();
 
    gl.clearColor(0.5, 0, 0,1);
    gl.enable(gl.DEPTH_TEST);
    gl.clear(gl.COLOR_BUFFER_BIT);

    ang += 0.01;
    ang1 += 0.03;

    gl.uniform1f(angUniformL, ang);
    gl.uniform1f(ang1UniformL, ang1);
    gl.drawArrays(gl.TRIANGLES, 0, vertices.length);
 
    window.requestAnimationFrame(draw);
}
 
function changeColor() {
    change_Color = !change_Color;
}

function genColor(color_arr, n_times) {
    
    var result = [];
    for (var i = 0; i < color_arr.length; i++) {
        for (var j = 0; j < n_times; j++) {
            result = result.concat(color_arr[i]);
        }
    }
 
 
    var result_buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, result_buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(result), gl.STATIC_DRAW);

    return result_buffer;
}
