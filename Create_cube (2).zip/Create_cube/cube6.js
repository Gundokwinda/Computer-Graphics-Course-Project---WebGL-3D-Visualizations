const canvas = document.querySelector(`canvas`);

const gl = canvas.getContext('webgl');

const vsSource = `
attribute vec2 vTexture;
attribute vec3 pos;
varying vec2 fragTexture;
uniform mat4 rotationMatrixX;
uniform mat4 rotationMatrixY;
uniform mat4 rotationMatrixZ;
uniform mat4 translationMatrix;
uniform mat4 viewMatrix; // Added view matrix uniform

void main() {
    vec3 adjustedPos = pos + vec3(1.5, 0.0, 0.0); // Move the triangle 1.5 units to the right
    vec4 rotatedPos = rotationMatrixX * rotationMatrixY * rotationMatrixZ * viewMatrix * vec4(adjustedPos * 0.5, 1); // Apply view matrix
    gl_Position = rotatedPos;
    fragTexture = vTexture;
}`;

const fsSource = `
precision mediump float;
varying vec2 fragTexture;
uniform sampler2D texture;
uniform sampler2D texture2;

void main() {
    gl_FragColor = texture2D(texture, fragTexture);
}`;

// Vertex shader compilation, program linking, and attribute locations remain the same

// Define the lookAt function
function lookAt(out, eye, center, up) {
    var zAxis = normalize(subtractVectors(eye, center));
    var xAxis = normalize(cross(up, zAxis));
    var yAxis = cross(zAxis, xAxis);

    out[0] = xAxis[0];
    out[1] = yAxis[0];
    out[2] = zAxis[0];
    out[3] = 0;
    out[4] = xAxis[1];
    out[5] = yAxis[1];
    out[6] = zAxis[1];
    out[7] = 0;
    out[8] = xAxis[2];
    out[9] = yAxis[2];
    out[10] = zAxis[2];
    out[11] = 0;
    out[12] = -dot(xAxis, eye);
    out[13] = -dot(yAxis, eye);
    out[14] = -dot(zAxis, eye);
    out[15] = 1;

    return out;
}

// Helper functions for vector operations
function normalize(v) {
    var length = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    if (length > 0.00001) {
        return [v[0] / length, v[1] / length, v[2] / length];
    } else {
        return [0, 0, 0];
    }
}

function subtractVectors(a, b) {
    return [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
}

function cross(a, b) {
    return [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0]
    ];
}

function dot(a, b) {
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

const vertexShader = gl.createShader(gl.VERTEX_SHADER);
gl.shaderSource(vertexShader, vsSource);
gl.compileShader(vertexShader);

const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(fragmentShader, fsSource);
gl.compileShader(fragmentShader);
function createRotationMatrixX(angleX) {
    const c = Math.cos(angleX);
    const s = Math.sin(angleX);

    return [
        1, 0, 0, 0,
        0, c, -s, 0,
        0, s, c, 0,
        0, 0, 0, 1,
    ];
}

function createRotationMatrixY(angleY) {
    const c = Math.cos(angleY);
    const s = Math.sin(angleY);

    return [
        c, 0, s, 0,
        0, 1, 0, 0,
        -s, 0, c, 0,
        0, 0, 0, 1,
    ];
}

function createRotationMatrixZ(angleZ) {
    const c = Math.cos(angleZ);
    const s = Math.sin(angleZ);

    return [
        c, s, 0, 0,
        -s, c, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1,
    ];
}

const program = gl.createProgram();
gl.attachShader(program, vertexShader);
gl.attachShader(program, fragmentShader);
gl.linkProgram(program);
gl.useProgram(program);
gl.enable(gl.DEPTH_TEST);
var r =0.5;//radius of a full circle
const vertices = new Float32Array([
    // Front square
    r,r,r,
	r,-r,r,
	-r,r,r,
	-r,r,r,
	r,-r,r,
	-r,-r,r,
	
	//back
	r,r,-r,
	r,-r,-r,
	-r,r,-r,
	-r,r,-r,
	r,-r,-r,
	-r,-r,-r,
	
	//top
	r,r,r,
	-r,r,r,
	-r,r,-r,
	r,r,r,
	-r,r,-r,
	r,r,-r,	
	
	//bottom
	r,-r,r,
	-r,-r,r,
	-r,-r,-r,
	r,-r,r,
	-r,-r,-r,
	r,-r,-r,

	//left
	-r,-r,r,
	-r,r,r,
	-r,-r,-r,
	-r,-r,-r,
	-r,r,r,
	-r,r,-r,	
	
	//right
	r,-r,r,
	r,r,r,
	r,-r,-r,
	r,-r,-r,
	r,r,r,
	r,r,-r,	
	
	]);

    

const texCoords = new Float32Array([
    // Front
    1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0,
    // Back
    0, 1, 0, 0, 1, 1, 1, 1, 0, 0, 1, 0,
    // Top
    1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1,
    // Bottom
    1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0,
    // Left
    1, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1,
    // Right
    0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1
]);


// Attribute and uniform locations, buffer creation, texture loading, and event listeners remain the same

function draw() {
    gl.clearColor(1, 1, 1, 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); // Clear depth buffer too

    const rotationMatrixX = new Float32Array(createRotationMatrixX(`angleX`));
    const rotationMatrixY = new Float32Array(createRotationMatrixY(`angleY`));
    const rotationMatrixZ = new Float32Array(createRotationMatrixZ(`angleZ`));
    const viewMatrixLocation = new Float32Array(createRotationMatrixZ(`angleZ`));
    // Define eye, center, and up vectors for the lookAt function
    const eye = [0, 0, 5]; // Eye position
    const center = [0, 0, 0]; // Center of the scene
    const up = [0, 1, 0]; // Up direction

    const viewMatrix = new Float32Array(16); // Initialize view matrix
    lookAt(viewMatrix, eye, center, up); // Calculate view matrix

    const rotMatLocX = gl.getUniformLocation(program, 'rotationMatrixX');
    const rotMatLocY = gl.getUniformLocation(program, 'rotationMatrixY');
    const rotMatLocZ = gl.getUniformLocation(program, 'rotationMatrixZ');
    
    gl.uniformMatrix4fv(rotMatLocX, false, rotationMatrixX);
    gl.uniformMatrix4fv(rotMatLocY, false, rotationMatrixY);
    gl.uniformMatrix4fv(rotMatLocZ, false, rotationMatrixZ);
   // gl.uniformMatrix4fv(viewMatrixLocation, false, viewMatrix); // Pass view matrix to the shader

    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.drawArrays(gl.TRIANGLES, 0, vertices.length);

    gl.uniformMatrix4fv(rotMatLocX2, false, rotationMatrixX2);
    gl.uniformMatrix4fv(rotMatLocY2, false, rotationMatrixY2);
    gl.uniformMatrix4fv(rotMatLocZ2, false, rotationMatrixZ2);
    gl.uniformMatrix4fv(viewMatrixLocation, false, viewMatrix); // Pass view matrix to the shader

    gl.bindTexture(gl.TEXTURE_2D, texture2);
    gl.drawArrays(gl.TRIANGLES, 0, vertices.length);

    angleX += 0.01;
    angleY += 0.01;
    angleX2 += 0.01;
    angleY2 += 0.01;

    window.requestAnimationFrame(draw);
}

// Event listeners for rotation and stop remain the same

draw();
