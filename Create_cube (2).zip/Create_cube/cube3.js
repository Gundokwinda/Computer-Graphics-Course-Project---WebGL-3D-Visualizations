const canvas = document.querySelector(`canvas`);

const gl = canvas.getContext('webgl');
const vertices = new Float32Array([
   //front square
   1, 1, 1,              
   -1, 1, 1,
   -1, -1, 1,
   1, 1, 1,
   -1, -1, 1,
   1, -1, 1,
   //back square
   1, 1, -1,
   -1, 1, -1,
   -1, -1, -1,
   
   1, 1, -1,
   -1, -1, -1,
   1, -1, -1,
   //right side
   1, 1, -1,
   1, 1, 1,
   1, -1, 1,
   1, 1, -1,
   1, -1, 1,
   1, -1, -1,
   //left side
   -1, 1, -1,
   -1, 1, 1,
   -1, -1, 1,
   -1, 1, -1,
   -1, -1, 1,
   -1, -1, -1,
   //top side
   1, 1, -1,
   -1, 1, -1,
   -1, 1, 1,
   1, 1,-1,    -1, 1, 1,
    1, 1, 1,
   //bottom side
   1, -1, -1,
   -1, -1, -1,
   -1, -1, 1,
   1, -1, -1,
   -1, -1, 1,
   1, -1, 1
]);





const buffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);


/* const colorbuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, colorbuffer);
gl.bufferData(gl.ARRAY_BUFFER, colorData, gl.STATIC_DRAW); */

const vsSource = `
attribute vec3 pos;
attribute vec3 color;
varying vec3 vColor;
uniform mat4 rotationMatrixX;
uniform mat4 rotationMatrixY;
uniform mat4 rotationMatrixZ;

void main() {
    vec4 rotatedPos = rotationMatrixX * rotationMatrixY * rotationMatrixZ * vec4(pos*0.25, 1);
    gl_Position = rotatedPos;
    vColor = color;
}`;

const fsSource = `
precision mediump float;
varying vec3 vColor;
void main() {
    gl_FragColor = vec4(vColor, 1);
}`;

const vertexShader = gl.createShader(gl.VERTEX_SHADER);
gl.shaderSource(vertexShader, vsSource);
gl.compileShader(vertexShader);

const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(fragmentShader, fsSource);
gl.compileShader(fragmentShader);

const program = gl.createProgram();
gl.attachShader(program, vertexShader);
gl.attachShader(program, fragmentShader);
gl.linkProgram(program);
gl.useProgram(program);

const positionLocation = gl.getAttribLocation(program, 'pos');
gl.enableVertexAttribArray(positionLocation);
gl.vertexAttribPointer(positionLocation, 3, gl.FLOAT, false, 0, 0);

const colorLocation = gl.getAttribLocation(program, 'color');
gl.enableVertexAttribArray(colorLocation);
gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
gl.vertexAttribPointer(colorLocation, 3, gl.FLOAT, false, 0, 0);

const rotationMatrixXLocation = gl.getUniformLocation(program, 'rotationMatrixX');
const rotationMatrixYLocation = gl.getUniformLocation(program, 'rotationMatrixY');
const rotationMatrixZLocation = gl.getUniformLocation(program, 'rotationMatrixZ');

function createRotationMatrixX(angle) {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    return [
        1, 0, 0, 0,
        0, cos, -sin, 0,
        0, sin, cos, 0,
        0, 0, 0, 1
    ];
}

function createRotationMatrixY(angle) {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    return [
        cos, 0, sin, 0,
        0, 1, 0, 0,
        -sin, 0, cos, 0,
        0, 0, 0, 1
    ];
}

function createRotationMatrixZ(angle) {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    return [
        cos, -sin, 0, 0,
        sin, cos, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1
    ];
}

let angleX = 0;
let angleY = 0;
let angleZ = 0;
gl.enable(gl.DEPTH_TEST);
function draw() {
    gl.clearColor(1, 0, 1, 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    const rotationMatrixX = new Float32Array(createRotationMatrixX(angleX));
    const rotationMatrixY = new Float32Array(createRotationMatrixY(angleY));
    const rotationMatrixZ = new Float32Array(createRotationMatrixZ(angleZ));

    gl.uniformMatrix4fv(rotationMatrixXLocation, false, rotationMatrixX);
    gl.uniformMatrix4fv(rotationMatrixYLocation, false, rotationMatrixY);
    gl.uniformMatrix4fv(rotationMatrixZLocation, false, rotationMatrixZ);

        gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.drawArrays(gl.TRIANGLE_FAN,0, vertices.length / 3);

    angleX += 0.01;
    angleY += 0.02;
    angleZ += 0.03;


    requestAnimationFrame(draw);
}

draw();
