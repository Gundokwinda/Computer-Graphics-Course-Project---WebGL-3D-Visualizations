const canvas = document.querySelector(`canvas`);


const gl = canvas.getContext('webgl');

const vsSource = `
attribute vec2 vTexture;
attribute vec3 pos;
varying vec2 fragTexture;
uniform mat4 rotationMatrixX;
uniform mat4 rotationMatrixY;
uniform mat4 rotationMatrixZ;
uniform mat4 translationMatrix;

void main() {
    vec3 adjustedPos = pos + vec3(1.5, 0.0, 0.0); // Move the triangle 1.5 units to the right
    vec4 rotatedPos = rotationMatrixX * rotationMatrixY * rotationMatrixZ * vec4(adjustedPos * 0.5, 1);
    gl_Position = rotatedPos;
    fragTexture = vTexture;
}`;

const fsSource = `
precision mediump float;
varying vec2 fragTexture;
uniform sampler2D texture;
uniform sampler2D texture2;

void main() {
    gl_FragColor = texture2D(texture, fragTexture);
}`;

const vertexShader = gl.createShader(gl.VERTEX_SHADER);
gl.shaderSource(vertexShader, vsSource);
gl.compileShader(vertexShader);

const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
gl.shaderSource(fragmentShader, fsSource);
gl.compileShader(fragmentShader);

const program = gl.createProgram();
gl.attachShader(program, vertexShader);
gl.attachShader(program, fragmentShader);
gl.linkProgram(program);
gl.useProgram(program);
gl.enable(gl.DEPTH_TEST);
var r =0.5;//radius of a full circle
const vertices = new Float32Array([
    // Front square
    r,r,r,
	r,-r,r,
	-r,r,r,
	-r,r,r,
	r,-r,r,
	-r,-r,r,
	
	//back
	r,r,-r,
	r,-r,-r,
	-r,r,-r,
	-r,r,-r,
	r,-r,-r,
	-r,-r,-r,
	
	//top
	r,r,r,
	-r,r,r,
	-r,r,-r,
	r,r,r,
	-r,r,-r,
	r,r,-r,	
	
	//bottom
	r,-r,r,
	-r,-r,r,
	-r,-r,-r,
	r,-r,r,
	-r,-r,-r,
	r,-r,-r,

	//left
	-r,-r,r,
	-r,r,r,
	-r,-r,-r,
	-r,-r,-r,
	-r,r,r,
	-r,r,-r,	
	
	//right
	r,-r,r,
	r,r,r,
	r,-r,-r,
	r,-r,-r,
	r,r,r,
	r,r,-r,	
	
	]);

    

const texCoords = new Float32Array([
    // Front
    1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0,
    // Back
    0, 1, 0, 0, 1, 1, 1, 1, 0, 0, 1, 0,
    // Top
    1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1,
    // Bottom
    1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0,
    // Left
    1, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1,
    // Right
    0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1
]);

const buffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

const textCoordBuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, textCoordBuffer);
gl.bufferData(gl.ARRAY_BUFFER, texCoords, gl.STATIC_DRAW);

const texture = gl.createTexture();
gl.bindTexture(gl.TEXTURE_2D, texture);

const texture2 = gl.createTexture();
gl.bindTexture(gl.TEXTURE_2D, texture2);

const image = new Image();
const image2 = new Image();
image.onload = function() {
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
}

image2.onload = function() {
    gl.bindTexture(gl.TEXTURE_2D, texture2);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image2);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
}
image.src = 'rubix.jpg';
image2.src = 'SMILE.jpg';

const positionLocation = gl.getAttribLocation(program, 'pos');
gl.enableVertexAttribArray(positionLocation);
gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
gl.vertexAttribPointer(positionLocation, 3, gl.FLOAT, false, 0, 0);

const textureLocation = gl.getAttribLocation(program, 'vTexture');
gl.enableVertexAttribArray(textureLocation);
gl.bindBuffer(gl.ARRAY_BUFFER, textCoordBuffer);
gl.vertexAttribPointer(textureLocation, 2, gl.FLOAT, false, 0, 0);

const rotMatLocX = gl.getUniformLocation(program, 'rotationMatrixX');
const rotMatLocY = gl.getUniformLocation(program, 'rotationMatrixY');
const rotMatLocZ = gl.getUniformLocation(program, 'rotationMatrixZ');

function createRotationMatrixX(angle) {
    const c = Math.cos(angle);
    const s = Math.sin(angle);

    return [
        1, 0, 0, 0,
        0, c, -s, 0,
        0, s, c, 0,
        0, 0, 0, 1,
    ];
}

function createRotationMatrixY(angle) {
    const c = Math.cos(angle);
    const s = Math.sin(angle);

    return [
        c, 0, s, 0,
        0, 1, 0, 0,
        -s, 0, c, 0,
        0, 0, 0, 1,
    ];
}


function createRotationMatrixZ(angle) {
    const c = Math.cos(angle);
    const s = Math.sin(angle);

    return [
        c, -s, 0, 0,
        s, c, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1,
    ];
}


let angleX = 0;
let angleY = 0;
let angleZ = 0;

let angleX2 = 0;
let angleY2 = 0;
let angleZ2 = 0;

function draw() {
    gl.clearColor(1, 1, 1, 1);
    gl.clear(gl.COLOR_BUFFER_BIT);

    const rotationMatrixX = new Float32Array(createRotationMatrixX(angleX));
    const rotationMatrixY = new Float32Array(createRotationMatrixY(angleY));
    const rotationMatrixZ = new Float32Array(createRotationMatrixZ(angleZ));

    const rotationMatrixX2 = new Float32Array(createRotationMatrixX(angleX2));
    const rotationMatrixY2 = new Float32Array(createRotationMatrixY(angleY2));
    const rotationMatrixZ2 = new Float32Array(createRotationMatrixZ(angleZ2));

    gl.uniformMatrix4fv(rotMatLocX, false, rotationMatrixX);
    gl.uniformMatrix4fv(rotMatLocY, false, rotationMatrixY);
    gl.uniformMatrix4fv(rotMatLocZ, false, rotationMatrixZ);

gl.bindTexture(gl.TEXTURE_2D,texture);
    gl.drawArrays(gl.TRIANGLES, 0, vertices.length / 3);

        
// Inside the draw function, adjust the rotation and rendering of the second triangle
gl.uniformMatrix4fv(rotMatLocX, false, rotationMatrixX2);
gl.uniformMatrix4fv(rotMatLocY, false, rotationMatrixY2);
gl.uniformMatrix4fv(rotMatLocZ, false, rotationMatrixZ2);

// Bind the texture for the second triangle
gl.bindTexture(gl.TEXTURE_2D, texture2);

// Draw the second triangle
gl.drawArrays(gl.TRIANGLES, 0, vertices.length / 3);
angleX += 0.01;
angleY += 0.01;
angleZ += 0.01;

angleX2 += 0.01;
angleY2 += 0.01;
angleZ2 += 0.01;

   
    

    window.requestAnimationFrame(draw);
}
const rotateX =document.getElementById('RotateX');
rotateX.addEventListener('click',function(){
    angleX += 0.1;
   

});

const rotateY=document.getElementById('RotateY');
rotateY.addEventListener('click',function(){
    angleY += 0.1;
   
 
});
const rotateZ =document.getElementById('RotateZ');
rotateZ.addEventListener('click',function(){
    angleZ += 0.1;
   
    
});


document.addEventListener('keydown', function(event) {
    if (event.key === 'ArrowRight') {
        angleY += 0.1;
    } 
     if (event.key === 'ArrowLeft') {
        angleY -= 0.1;
    } else if (event.key === 'ArrowUp') {
        angleX -= 0.1;
    } else if (event.key === 'ArrowDown') {
        angleX += 0.1;
    }
  });
  document.addEventListener('keydown', function(event) {
    if (event.key === 'd') {
        angleY2 += 0.1;
    } 
     if (event.key === 'a') {
        angleY2 -= 0.1;
    } else if (event.key === 'a') {
        angleX2 -= 0.1;
    } else if (event.key === 'w') {
        angleX2 += 0.1;
    }
  });
draw();

